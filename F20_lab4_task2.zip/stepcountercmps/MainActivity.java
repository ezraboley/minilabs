package com.badger.stepcountercmps;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    public int stepcounter = 0;
    public boolean duringStep = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(final SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            float accelerationSquareRoot = (x * x + y * y + z * z)
                    / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
            if (accelerationSquareRoot > 1.5 && !duringStep){
                stepcounter += 1;
                duringStep = true;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final TextView step = findViewById(R.id.stepcounter);
                        step.post(new Runnable() {
                            @Override
                            public void run() {
                                step.setText(String.valueOf(stepcounter));
                            }
                        });
                    }
                }).start();
            }else if (accelerationSquareRoot < 1.5 && duringStep){duringStep = false;}
        }
        if (event.sensor.getType() == Sensor.TYPE_ORIENTATION){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final TextView orientview = findViewById(R.id.orientation);
                    orientview.post(new Runnable() {
                        @Override
                        public void run() {
                            float orient = event.values[0];
                            if (orient >= 0 && orient < 22.5){
                                orientview.setText("North");
                            }else if (orient >= 22.5 && orient < 67.5){
                                orientview.setText("NE");
                            }else if (orient >= 67.5 && orient < 112.5){
                                orientview.setText("East");
                            }else if (orient >= 112.5 && orient < 157.5){
                                orientview.setText("SE");
                            }else if (orient >= 157.5 && orient < 202.5){
                                orientview.setText("South");
                            }else if (orient >= 202.5 && orient < 247.5){
                                orientview.setText("SW");
                            }else if (orient >= 247.5 && orient < 292.5){
                                orientview.setText("West");
                            }else if (orient >= 292.5 && orient < 337.5){
                                orientview.setText("NW");
                            }else if (orient >= 337.5 && orient < 360){
                                orientview.setText("North");
                            }else{
                                orientview.setText("Unknown");
                            }
                        }
                    });
                }
            }).start();
        }

    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
